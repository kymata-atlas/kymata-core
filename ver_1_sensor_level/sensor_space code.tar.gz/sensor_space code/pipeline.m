
%---------------------------------------------
% This file is a pipe-line that takes a fif. file, triggers and
% model-signals and output the statistical likelihood of the information of
% model-signal being found in each of the MEG channels.
%---------------------------------------------

stimuilsig.

Exractlexpro (ignore if already done?)
     
append to MEG data

save.

testfor rho, xxx, or xxx, xxx

do jonathon's thing' on it.

Print out